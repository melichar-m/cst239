module weapons.java {
}