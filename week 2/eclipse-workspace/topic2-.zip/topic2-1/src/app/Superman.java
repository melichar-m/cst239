package app;

public class Superman extends SuperHero
{
	public Superman(int health)
	{
		super("Superman",health);
	}
}
