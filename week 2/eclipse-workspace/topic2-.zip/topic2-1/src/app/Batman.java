package app;

public class Batman extends SuperHero
{
	public Batman(int health)
	{
		super("Batman",health);
	}
}
